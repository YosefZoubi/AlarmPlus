package com.example.alarmplus;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.TaskStackBuilder;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ForegroundService extends Service {
    public static final String CHANNEL_ID = "ForegroundServiceChannel";
    NotificationManager mNotiMgr;
    Notification.Builder mNotifyBuilder;
    Runnable test;
    MediaPlayer mediaPlayer;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate() {
        super.onCreate();
        initForeground();
        mediaPlayer = MediaPlayer.create(this,R.raw.vibrate);
        mediaPlayer.setLooping(false);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        //stopSelf();
        startForeground(1, updateNotification("No ringing alarm"));

        final Handler handler = new Handler();
        test = new Runnable() {

            @Override
            public void run() {
                Calendar rightNow = Calendar.getInstance();
                int currentHourIn24Format = rightNow.get(Calendar.HOUR_OF_DAY);
                int currentMins = rightNow.get(Calendar.MINUTE);

                AppDataBase abc = AppDataBase.getInstance(getApplicationContext());
                List<alarmDetails> list = abc.noteDao().getAllDetails();
                for(alarmDetails alarm : list){
                    if(alarm.hour == currentHourIn24Format && alarm.minute == currentMins){
                        updateNotification("Ringing now at " + currentHourIn24Format + ":" + currentMins);
                        mediaPlayer.start();
                    }else{
                        updateNotification("No ringing alarm");
                    }
                }

                //check if there is alarm to delete by create time
                Calendar c = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                String strDate = sdf.format(c.getTime());

                for(int i =0; i < MyAdapter.listner.alarms.size(); i++) 
                {
                    //get time creation of alarm
                    String createalarm = MyAdapter.listner.alarms.get(i).getCreate();
                    int dd = Integer.parseInt(createalarm.substring(0,2));
                    int mm = Integer.parseInt(createalarm.substring(3,5));
                    int yyyy = Integer.parseInt(createalarm.substring(6,10));
                    int hh = Integer.parseInt(createalarm.substring(11,13));
                    int mmin = Integer.parseInt(createalarm.substring(14,16));

                    //get time now
                    int dd2 = Integer.parseInt(strDate.substring(0,2));
                    int mm2 = Integer.parseInt(strDate.substring(3,5));
                    int yyyy2 = Integer.parseInt(strDate.substring(6,10));
                    int hh2 = Integer.parseInt(strDate.substring(11,13));
                    int mmin2 = Integer.parseInt(strDate.substring(14,16));


                    if((hh == hh2) && (mmin + 1 == mmin2) && (dd==dd2) && (mm == mm2) && (yyyy == yyyy2))
                    {
                        AppDataBase abc1 = AppDataBase.getInstance(getApplicationContext());
                        abc1.noteDao().delete(MyAdapter.listner.alarms.get(i).getHour(),MyAdapter.listner.alarms.get(i).getMins());
                        MyAdapter.listner.alarms.remove(i);
                        MyAdapter.listner.notifyDataSetChanged();
                    }
                }

                handler.postDelayed(test,1000);
            }
        };

        handler.postDelayed(test, 0);




        return START_STICKY;
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void initForeground(){
        String CHANNEL_ID = "my_channel_01";
        if (mNotiMgr==null)
            mNotiMgr= (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "My main channel",
                NotificationManager.IMPORTANCE_DEFAULT);
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                .createNotificationChannel(channel);

        mNotifyBuilder = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("no ringing alarm")
                .setSmallIcon(R.drawable.ic_baseline_alarm_add_24)
                .setAutoCancel(true);

    }
    public Notification updateNotification(String details){
        mNotifyBuilder.setContentText(details).setOnlyAlertOnce(false);
        Notification noti = mNotifyBuilder.build();
        noti.flags = Notification.FLAG_ONLY_ALERT_ONCE;
        mNotiMgr.notify(1, noti);
        return noti;
    }


}